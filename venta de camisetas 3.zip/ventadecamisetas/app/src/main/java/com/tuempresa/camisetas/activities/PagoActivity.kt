package com.example.ventadecamisetas

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tuempresa.camisetas.R

class PagoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pago)

        val btnContinuar = findViewById<Button>(R.id.btnContinuarPago)

        btnContinuar.setOnClickListener {
            // Aquí podrías validar que hayan seleccionado una opción
            val intent = Intent(this, RegistroUsuarioActivity::class.java)
            startActivity(intent)
        }
    }
}

