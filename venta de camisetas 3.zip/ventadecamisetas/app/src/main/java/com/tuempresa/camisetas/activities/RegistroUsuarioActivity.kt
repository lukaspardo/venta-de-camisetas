package com.example.ventadecamisetas

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tuempresa.camisetas.R
import com.tuempresa.camisetas.activities.ComprobanteActivity

class RegistroUsuarioActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_usuario)

        val btnFinalizar = findViewById<Button>(R.id.btnFinalizarCompra)

        // Dentro de RegistroUsuarioActivity.kt
        btnFinalizar.setOnClickListener {
            // Aquí puedes guardar en la DB si lo deseas
            val intent = Intent(this, ComprobanteActivity::class.java)
            startActivity(intent)
        }
    }
}