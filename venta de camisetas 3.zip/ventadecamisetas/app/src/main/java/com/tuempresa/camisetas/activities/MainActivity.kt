
package com.tuempresa.camisetas.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tuempresa.camisetas.R
import com.tuempresa.camisetas.adapters.CamisetaAdapter
import com.tuempresa.camisetas.models.Camiseta

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recycler = findViewById<RecyclerView>(R.id.recyclerCamisetas)
        recycler.layoutManager = LinearLayoutManager(this)

        val lista = listOf(
            Camiseta(R.drawable.madrid, "Real Madrid 17/18", "$160.000"),
            Camiseta(R.drawable.barcelona, "Barcelona 25/26", "$120.000"),
            Camiseta(R.drawable.acmilan, "acmilan 24/25", "$120.000"),
        )

        recycler.adapter = CamisetaAdapter(lista, this)
    }

    // 1. Este método "infla" (muestra) el menú en la barra superior
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    // 2. Este método detecta cuando alguien toca "Ver Carrito"
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_ver_carrito) {
            // Esto te lleva a la lista del carrito (donde arreglamos el botón de pago)
            val intent = Intent(this, com.tuempresa.camisetas.activities.CarritoActivity::class.java)
            startActivity(intent)
            return true
        }
        return super.onOptionsItemSelected(item)

    }
}
